// Import functions to fetch data from the API
import { getPhotos, editPhotoById } from './api.js';

// Function to display photos
async function displayPhotos() {
    const photosContainer = document.getElementById('photosContainer');

    try {
        const photos = await getPhotos();

        if (photos && photos.length > 0) {
            photosContainer.innerHTML = '';

            photos.forEach((photo) => {
                const photoElement = document.createElement('div');
                photoElement.classList.add('col-md-4', 'mb-4');

                const imageElement = document.createElement('img');
                imageElement.src = photo.images;
                imageElement.alt = photo.title;
                imageElement.dataset.id = photo.id;
                imageElement.classList.add('img-fluid', 'rounded');
                photoElement.appendChild(imageElement);

                imageElement.addEventListener('click', () => {
                    const existingInfoElement = photoElement.querySelector('.photo-info');
                    if (existingInfoElement) {
                        photoElement.removeChild(existingInfoElement);
                    }

                    const infoElement = document.createElement('div');
                    infoElement.classList.add('photo-info');
                    infoElement.innerHTML = `
                        <p>Title: ${photo.title}</p>
                        <p>Author: ${photo.author}</p>
                        <p>Views: ${photo.views}</p>
                        <p>Tags: ${Array.isArray(photo.tags) ? photo.tags.join(', ') : ''}</p>
                        <p>Published at: ${photo.published_at}</p>
                        <div class="icons">
                            <i class="bi bi-pencil-square" data-bs-toggle="modal" data-bs-target="#editModal"></i>
                        </div>
                    `;
                    photoElement.appendChild(infoElement);

                    const editIcon = infoElement.querySelector('.bi-pencil-square');
                    editIcon.addEventListener('click', () => {
                        const selectedPhotoId = photo.id;

                        document.getElementById('title').value = photo.title;
                        document.getElementById('author').value = photo.author;
                        document.getElementById('views').value = photo.views;
                        document.getElementById('tags').value = Array.isArray(photo.tags) ? photo.tags.join(', ') : '';
                        document.getElementById('images').value = photo.images;
                        document.getElementById('selectedPhotoId').value = selectedPhotoId;

                        $('#editModal').modal('show');
                    });
                });

                document.addEventListener('click', (event) => {
                    const clickedInsidePhoto = photoElement.contains(event.target);
                    if (!clickedInsidePhoto) {
                        const infoElement = photoElement.querySelector('.photo-info');
                        if (infoElement) {
                            photoElement.removeChild(infoElement);
                        }
                    }
                });

                photosContainer.appendChild(photoElement);
            });
        } else {
            photosContainer.innerHTML = '<p>No photos found.</p>';
        }
    } catch (error) {
        console.error('Error displaying photos:', error);
        photosContainer.innerHTML = '<p>Error loading photos.</p>';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    displayPhotos();
});

const editPhotoForm = document.getElementById('editPhotoForm');
editPhotoForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const selectedPhotoId = document.getElementById('selectedPhotoId').value;

    const updatedPhotoData = {
        title: document.getElementById('title').value,
        author: document.getElementById('author').value,
        views: document.getElementById('views').value,
        tags: document.getElementById('tags').value.split(',').map(tag => tag.trim()),
        images: document.getElementById('images').value,
    };

    try {
        await editPhotoById(selectedPhotoId, updatedPhotoData);
        displayPhotos();
        $('#editModal').modal('hide');
    } catch (error) {
        console.error('Error editing photo:', error);
    }
});
